<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BetSettings extends Model
{   protected $table="bet_settings";
    // protected $fillable=[
    //    "admin_id" ,"min_bet","max_bet", "max_market","bet_market", "sport_name","created_at", "updated_at","deleted_at",
    // ];
   // use HasFactory;
}
