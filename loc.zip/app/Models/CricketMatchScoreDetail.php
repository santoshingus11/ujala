<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CricketMatchScoreDetail extends Model
{
    use HasFactory;
    protected $table = 'cricket_matches_score_detail';
     protected $guarded = [];  
}
