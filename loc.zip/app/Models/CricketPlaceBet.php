<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CricketPlaceBet extends Model
{
    use HasFactory;
    protected $table = 'cricket_place_bet';
}
