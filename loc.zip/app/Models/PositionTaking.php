<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PositionTaking extends Model
{   protected $table= "position_taking";
    use HasFactory;
}
