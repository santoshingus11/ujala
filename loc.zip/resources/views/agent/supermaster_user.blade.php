<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="editModalLabel">Edit Privileges</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
       
        <div id="supermasteruser">
           
        </div>
        <div id="passwordchange">
            
        </div>
    </div>
</div>