 <style>
   .sidebar .sidebar-body .nav .nav-item .nav-link {
     padding: 0px 15px !important;
     height: 40px !important;
   }
 </style>



 <nav class="sidebar">
   <div class="sidebar-header">
     <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-brand">
       <img src="<?php echo e(asset('admin/assets/img/logo.png')); ?>">
     </a>
     <div class="sidebar-toggler not-active">
       <span></span>
       <span></span>
       <span></span>
     </div>
   </div>
   <div class="sidebar-body top-bg">
    <?php if((Auth::guard('agent')->user()->user_access=='1')): ?>
    <?php echo $__env->make('agent.user_access_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
     <?php echo $__env->make('agent.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php endif; ?>
   </div>
 </nav><?php /**PATH /home/u967365359/domains/ujala11games.com/public_html/resources/views/layouts/left-side-bar.blade.php ENDPATH**/ ?>