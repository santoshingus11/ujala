<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="">
  <meta name="author" content="NobleUI">
  <meta name="keywords" content="">
  <?php echo $__env->make('layouts.header-url', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
  <div class="main-wrapper Dashboard-bg admin-bg customResponsive">
    <!-- partial:partials/_sidebar.html -->
    <div class="left-side-bar"><?php echo $__env->make('layouts.left-side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    <div class="page-wrapper bg-none">
      <!-- partial:partials/_navbar.html -->
      <div class="top-header-section"><?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
      <!-- partial -->
      <div class="page-content">
        <div class="Welcometo-section">
          <?php echo $__env->make('layouts.top-balance-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="createagent main-bg py-4 px-4">
          <div class="row">

          <form action="<?php echo e(route('update-notification')); ?>" method="post" class="forms-sample">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="type"  value="news" >
            <div class="col-lg-12 col-md-6 col-sm-12">
              <div class="Information Information-bg px-4 py-4 w-100">
                <div class="card-body">
                  <h5 class="border-bottom mb-3 pb-1"> News Update</h5>                
                    <div class="mb-3">
                      <textarea class="form-control" name="description" id="exampleFormControlTextarea1" placeholder="News Update" rows="5"></textarea>
                    </div>
                 
                </div>
              </div>
            </div>

            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="Information px-4 py-4 right">
                <div class="serch-filter">
                  <button type="submit" class="btn btn-primary New-Agent btn-icon-text mb-2 mb-md-0">
                    Update News
                  </button>
                </div>
              </div>
            </div>

            </form>

          </div>
        </div>


      </div>
    </div>
  </div>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u254575789/domains/lordexworld.com/public_html/resources/views/agent/news-update.blade.php ENDPATH**/ ?>