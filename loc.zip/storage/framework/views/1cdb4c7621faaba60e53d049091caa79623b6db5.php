<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="keywords" content="">
  <?php echo $__env->make('layouts.header-url', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    // Wait for the DOM to be ready
    document.addEventListener("DOMContentLoaded", function() {
      var startDateInput = document.getElementById("start-date");
      var endDateInput = document.getElementById("end-date");

      // Get today's date in the format "YYYY-MM-DD"
      var today = new Date().toISOString().split('T')[0];

      // Set initial values for date inputs
      startDateInput.value = today;
      endDateInput.value = today;

      // Initialize date picker for start date
      flatpickr(startDateInput, {
        dateFormat: "Y-m-d",
        onChange: function(selectedDates, dateStr) {
          endDatePicker.set("minDate", dateStr);
        }
      });

      // Initialize date picker for end date
      var endDatePicker = flatpickr(endDateInput, {
        dateFormat: "Y-m-d",
        onChange: function(selectedDates, dateStr) {
          startDatePicker.set("maxDate", dateStr);
        }
      });
    });
  </script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/css/bootstrap-datepicker.min.css" integrity="sha512-34s5cpvaNG3BknEWSuOncX28vz97bRI59UnVtEEpFX536A7BtZSJHsDyFoCl8S7Dt2TPzcrCEoHBGeM4SUBDBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>


  <div class="main-wrapper Dashboard-bg customResponsive">
    <!-- partial:partials/_sidebar.html -->
    <div class="left-side-bar"><?php echo $__env->make('layouts.left-side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    <div class="page-wrapper bg-none">
      <!-- partial:partials/_navbar.html -->
      <div class="top-header-section"><?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
      <!-- partial -->
      <div class="page-content">
        <?php echo $__env->make('layouts.top-balance-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
          <div class="col-12 col-xl-12 grid-margin stretch-card">
            <div class="card overflow-hidden">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success mt-3">
                            <p><?php echo e(Session::get('message')); ?></p>
                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mt-3">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                 <h4 class=" mb-0">Change Cricket Match Status</h4>
                  <div class="d-flex align-items-center flex-wrap text-nowrap">
                  <input type="hidden" name="type" id="type" value="p_l">
                  <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">

                    

                  </div>
                </div>

                    <form action="<?php echo e(route('admin-change-cricket-match-status-submit')); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-4">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="mybets-date-picker">
                                <div class="row">
                                    <h5 class="mt-2 mb-2">Active/Inactive This Match <span style="color:red;">( <?php echo e($cricket->team_name); ?> )</span>:</h5>
                                    <div class="col-lg-1">
                                       <div class="form-check">
                                          <input class="form-check-input" type="radio" name="status" id="active" value="1" <?php echo e($currentStatus==1 ? ' checked' : ''); ?> required>
                                          <label class="form-check-label" for="active">
                                            Activate
                                          </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                       <div class="form-check">
                                          <input class="form-check-input" type="radio" name="status" id="inactive" value="0" <?php echo e($currentStatus==0 ? ' checked' : ''); ?> required>
                                          <label class="form-check-label" for="inactive">
                                            Inactivate
                                          </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-9"></div>
                                    
                                </div>
                                
                                <div class="row mt-5">
                                    <h5 class="mt-2 mb-2">Win-Loss Setup:</h5>
                                    <div class="col-lg-2">
                                       <div class="form-check">
                                          <input class="form-check-input" type="radio" name="win_loss" id="win_back" value="back" <?php echo e($win_loss=='back' ? ' checked' : ''); ?>>
                                          <label class="form-check-label" for="win_back">
                                            Win Back
                                          </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                       <div class="form-check">
                                          <input class="form-check-input" type="radio" name="win_loss" id="win_lay" value="lay" <?php echo e($win_loss=='lay' ? ' checked' : ''); ?>>
                                          <label class="form-check-label" for="win_lay">
                                            Win Lay
                                          </label>
                                        </div>
                                    </div>
                                    <div class="col-lg-8"></div>
                                    
                                    <div class="col-lg-12 text-left">
                                        <label for="toDate" class="col-12 col-form-label w-100 height-24"></label>
                                        <button class="btn btn-primary" style="height: 35px;">SUBMIT</button>
                                    </div>
                                </div>
                                
                                
                            </div>
                            </div>
                        </div>
                        <input type="hidden" value="<?php echo e($gameid); ?>" name="game_id">
                        <input type="hidden" value="<?php echo e($id); ?>" name="id">
                    </form>

                  </div>
                </div>
              </div>
            </div>
             
             
             <!--<div class="row">-->
             <!--    <div class="col-md-3">-->
             <!--        <a href="https://crickekbuz.art/cricket/track-match-result" class="btn btn-lg btn-danger">Cricketbuzz Result</a>-->
             <!--    </div>-->
             <!--</div>-->
            
            
          </div>

      </div>
     
    </div>
  </div>

<script>
    $(function() {
        // validation error msg
        $('.alert').delay(3000).fadeOut('slow');

    });
</script>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/js/bootstrap-datepicker.min.js" integrity="sha512-LsnSViqQyaXpD4mBBdRYeP6sRwJiJveh2ZIbW41EBrNmKxgr/LFZIiWT6yr+nycvhvauz8c2nYMhrP80YhG7Cw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
  $( function() {
    $('#bonus_expired_date').datepicker({
        format: 'yyyy-mm-dd'
    }).datepicker("setDate",'now');
  } );
</script>

<?php /**PATH /home/u967365359/domains/ujala11games.com/public_html/resources/views/agent/cricket/change-cricket-match-status.blade.php ENDPATH**/ ?>