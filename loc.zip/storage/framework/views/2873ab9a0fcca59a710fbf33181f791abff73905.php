<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="">
  <meta name="author" content="NobleUI">
  <meta name="keywords" content="">
  <?php echo $__env->make('layouts.header-url', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>


  <div class="main-wrapper Dashboard-bg customResponsive">
    <!-- partial:partials/_sidebar.html -->
    <div class="left-side-bar"><?php echo $__env->make('layouts.left-side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    <div class="page-wrapper bg-none">
      <!-- partial:partials/_navbar.html -->
      <div class="top-header-section"><?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
      <!-- partial -->
     
      
      <div class="page-content">
        
       
   <div class="row">
              <div class="col-12 col-xl-12 grid-margin stretch-card">
                <div class="card overflow-hidden">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                     <h4 class=" mb-0">Cricket Match Bet List</h4>
                     <h4 class=" mb-0 align-right">Total : <?php echo e($response['response']['CricketPlaceBetcount'] ?? ""); ?></h4>
                      <div class="d-flex align-items-center flex-wrap text-nowrap">
                      <input type="hidden" name="type" id="type" value="p_l">
                      <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">
    
    
                      </div>
                    </div>
    
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-dark">
                              <tr>
                              <th class="text-center">Bet ID</th>
                                <th class="text-center">Event Name</th>
                                <th class="text-center">Event Type</th>
                                <th class="text-center">Back/Lay</th>
                                <th class="text-center">Bet stake</th>
                                <th class="text-center">Placed Time</th>
                                <th class="text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            
                             <?php if(!empty($response['response']['CricketPlaceBet'])): ?>
                             <?php $__currentLoopData = $response['response']['CricketPlaceBet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CricketPlaceBetval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="back">
                                <td class="text-center"><?php echo e($CricketPlaceBetval['id']); ?></td>
                                <td class="text-center"><?php echo e($CricketPlaceBetval['team_name']); ?></td>
                                <td class="text-center">Cricket</td>
                                <td class="text-center"><?php echo e($CricketPlaceBetval['back_lay']); ?></td>
                                <td class="text-center"><?php echo e($CricketPlaceBetval['bet_stake']); ?></td>
                               
                                
                                <td class="text-center"><?php echo e($CricketPlaceBetval['created_at']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_reject',['id'=>$CricketPlaceBetval['id'],'website'=>$website,'game'=>'Cricket'])); ?>" class="btn btn-danger">Reject</a>
                                      <?php if(!empty($CricketPlaceBetval['status']) == 0): ?>
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_accept',['id'=>$CricketPlaceBetval['id'],'website'=>$website,'game'=>'Cricket'])); ?>" class="btn btn-success">Accept</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
    
                    <div class="border-bottom mt-3"></div>
    
                  </div>
                </div>
              </div>
            </div>

<div class="row">
              <div class="col-12 col-xl-12 grid-margin stretch-card">
                <div class="card overflow-hidden">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                     <h4 class=" mb-0">Football Match Bet List</h4>
                     <h4 class=" mb-0 align-right">Total : <?php echo e($response['response']['FootballPlaceBetcount'] ?? ""); ?></h4>
                      <div class="d-flex align-items-center flex-wrap text-nowrap">
                      <input type="hidden" name="type" id="type" value="p_l">
                      <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">
    
    
                      </div>
                    </div>
    
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-dark">
                              <tr>
                              <th class="text-center">Bet ID</th>
                                <th class="text-center">Event Name</th>
                                <th class="text-center">Event Type</th>
                                <th class="text-center">Back/Lay</th>
                                <th class="text-center">Bet stake</th>
                                <th class="text-center">Placed Time</th>
                                <th class="text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            
                             <?php if(!empty($response['response']['FootballPlaceBet'])): ?>
                             <?php $__currentLoopData = $response['response']['FootballPlaceBet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FootballPlaceBetval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="back">
                                <td class="text-center"><?php echo e($FootballPlaceBetval['id']); ?></td>
                                <td class="text-center"><?php echo e($FootballPlaceBetval['team_name']); ?></td>
                                <td class="text-center">FootBall</td>
                                <td class="text-center"><?php echo e($FootballPlaceBetval['back_lay']); ?></td>
                                <td class="text-center"><?php echo e($FootballPlaceBetval['bet_stake']); ?></td>
                               
                                
                                <td class="text-center"><?php echo e($FootballPlaceBetval['created_at']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_reject',['id'=>$FootballPlaceBetval['id'],'website'=>$website,'game'=>'FootBall'])); ?>" class="btn btn-danger">Reject</a>
                                     <?php if(!empty($FootballPlaceBetval['status']) == 0): ?>
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_accept',['id'=>$FootballPlaceBetval['id'],'website'=>$website,'game'=>'FootBall'])); ?>" class="btn btn-success">Accept</a>
                                     <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
    
                    <div class="border-bottom mt-3"></div>
    
                  </div>
                </div>
              </div>
            </div>


<div class="row">
              <div class="col-12 col-xl-12 grid-margin stretch-card">
                <div class="card overflow-hidden">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                     <h4 class=" mb-0">Tennis Match Bet List</h4>
                     <h4 class=" mb-0 align-right">Total : <?php echo e($response['response']['TennisPlaceBetcount'] ?? ""); ?></h4>
                      <div class="d-flex align-items-center flex-wrap text-nowrap">
                      <input type="hidden" name="type" id="type" value="p_l">
                      <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">
    
    
                      </div>
                    </div>
    
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-dark">
                              <tr>
                              <th class="text-center">Bet ID</th>
                                <th class="text-center">Event Name</th>
                                <th class="text-center">Event Type</th>
                                <th class="text-center">Back/Lay</th>
                                <th class="text-center">Bet stake</th>
                                <th class="text-center">Placed Time</th>
                                <th class="text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            
                             <?php if(!empty($response['response']['TennisPlaceBet'])): ?>
                             <?php $__currentLoopData = $response['response']['TennisPlaceBet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TennisPlaceBetval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="back">
                                <td class="text-center"><?php echo e($TennisPlaceBetval['id']); ?></td>
                                <td class="text-center"><?php echo e($TennisPlaceBetval['team_name']); ?></td>
                                <td class="text-center">Tennis</td>
                                <td class="text-center"><?php echo e($TennisPlaceBetval['back_lay']); ?></td>
                                <td class="text-center"><?php echo e($TennisPlaceBetval['bet_stake']); ?></td>
                               
                                
                                <td class="text-center"><?php echo e($TennisPlaceBetval['created_at']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_reject',['id'=>$TennisPlaceBetval['id'],'website'=>$website,'game'=>'Tennis'])); ?>" class="btn btn-danger">Reject</a>
                                    
                                     <?php if(!empty($TennisPlaceBetval['status']) == 0): ?>
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_accept',['id'=>$TennisPlaceBetval['id'],'website'=>$website,'game'=>'Tennis'])); ?>" class="btn btn-success">Accept</a>
                                     <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
    
                    <div class="border-bottom mt-3"></div>
    
                  </div>
                </div>
              </div>
            </div>

<div class="row">
              <div class="col-12 col-xl-12 grid-margin stretch-card">
                <div class="card overflow-hidden">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                     <h4 class=" mb-0">HorseRacing Match Bet List</h4>
                     <h4 class=" mb-0 align-right">Total : <?php echo e($response['response']['HorseRacingPlaceBetcount'] ?? ""); ?></h4>
                      <div class="d-flex align-items-center flex-wrap text-nowrap">
                      <input type="hidden" name="type" id="type" value="p_l">
                      <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">
    
    
                      </div>
                    </div>
    
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-dark">
                              <tr>
                              <th class="text-center">Bet ID</th>
                                <th class="text-center">Event Name</th>
                                <th class="text-center">Event Type</th>
                                <th class="text-center">Back/Lay</th>
                                <th class="text-center">Bet stake</th>
                                <th class="text-center">Placed Time</th>
                                <th class="text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            
                             <?php if(!empty($response['response']['HorseRacingPlaceBet'])): ?>
                             <?php $__currentLoopData = $response['response']['HorseRacingPlaceBet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HorseRacingPlaceBetval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="back">
                                <td class="text-center"><?php echo e($HorseRacingPlaceBetval['id']); ?></td>
                                <td class="text-center"><?php echo e($HorseRacingPlaceBetval['team_name']); ?></td>
                                <td class="text-center">HorseRacing</td>
                                <td class="text-center"><?php echo e($HorseRacingPlaceBetval['back_lay']); ?></td>
                                <td class="text-center"><?php echo e($HorseRacingPlaceBetval['bet_stake']); ?></td>
                               
                                
                                <td class="text-center"><?php echo e($HorseRacingPlaceBetval['created_at']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_reject',['id'=>$HorseRacingPlaceBetval['id'],'website'=>$website,'game'=>'HorseRacing'])); ?>" class="btn btn-danger">Reject</a>
                                       <?php if(!empty($HorseRacingPlaceBetval['status']) == 0): ?>
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_accept',['id'=>$HorseRacingPlaceBetval['id'],'website'=>$website,'game'=>'HorseRacing'])); ?>" class="btn btn-success">Accept</a>
                                     <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
    
                    <div class="border-bottom mt-3"></div>
    
                  </div>
                </div>
              </div>
            </div>

<div class="row">
              <div class="col-12 col-xl-12 grid-margin stretch-card">
                <div class="card overflow-hidden">
                  <div class="card-body">
                    <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                     <h4 class=" mb-0">GreyhoundRacing Match Bet List</h4>
                     <h4 class=" mb-0 align-right">Total : <?php echo e($response['response']['GreyhoundRacingPlaceBetcount'] ?? ""); ?></h4>
                      <div class="d-flex align-items-center flex-wrap text-nowrap">
                      <input type="hidden" name="type" id="type" value="p_l">
                      <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">
    
    
                      </div>
                    </div>
    
                    <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-dark">
                              <tr>
                              <th class="text-center">Bet ID</th>
                                <th class="text-center">Event Name</th>
                                <th class="text-center">Event Type</th>
                                <th class="text-center">Back/Lay</th>
                                <th class="text-center">Bet stake</th>
                                <th class="text-center">Placed Time</th>
                                <th class="text-center">Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            
                             <?php if(!empty($response['response']['GreyhoundRacingPlaceBet'])): ?>
                             <?php $__currentLoopData = $response['response']['GreyhoundRacingPlaceBet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $GreyhoundRacingPlaceBetval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="back">
                                <td class="text-center"><?php echo e($GreyhoundRacingPlaceBetval['id']); ?></td>
                                <td class="text-center"><?php echo e($GreyhoundRacingPlaceBetval['team_name']); ?></td>
                                <td class="text-center">GreyhoundRacing</td>
                                <td class="text-center"><?php echo e($GreyhoundRacingPlaceBetval['back_lay']); ?></td>
                                <td class="text-center"><?php echo e($GreyhoundRacingPlaceBetval['bet_stake']); ?></td>
                               
                                
                                <td class="text-center"><?php echo e($GreyhoundRacingPlaceBetval['created_at']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_reject',['id'=>$GreyhoundRacingPlaceBetval['id'],'website'=>$website,'game'=>'GreyhoundRacing'])); ?>" class="btn btn-danger">Reject</a>
                                    <?php if(!empty($GreyhoundRacingPlaceBetval['status']) == 0): ?>
                                    <a href="<?php echo e(route('admin_website_dashboard_detail_accept',['id'=>$GreyhoundRacingPlaceBetval['id'],'website'=>$website,'game'=>'GreyhoundRacing'])); ?>" class="btn btn-success">Accept</a>
                                     <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
    
                    <div class="border-bottom mt-3"></div>
    
                  </div>
                </div>
              </div>
            </div>

      </div>
    </div>
  </div>



    

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u967365359/domains/ujala11games.com/public_html/resources/views/agent/admin/detail.blade.php ENDPATH**/ ?>