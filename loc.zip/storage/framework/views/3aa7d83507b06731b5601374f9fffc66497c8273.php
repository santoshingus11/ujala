<?php if($past_bet_list->count()>0): ?>
<?php $__currentLoopData = $past_bet_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($bl->username); ?></td>
<td>--</td>
<td>--</td>
<td><?php if($bl->in_play==1): ?><?php echo e('Yes'); ?><?php else: ?><?php echo e('NO'); ?><?php endif; ?></td>
<td><?php if($bl->one_click==1): ?><?php echo e('Yes'); ?><?php else: ?><?php echo e('NO'); ?><?php endif; ?></td>
<td><?php echo e($bl->odd_req); ?></td>
<td><?php echo e($bl->bet_placed); ?></td>
<td><?php if($bl->result==1): ?><?php echo e($bl->bet_placed*($bl->odd_req-1)); ?><?php else: ?><?php echo e('0.00'); ?><?php endif; ?></td>
<td><?php if($bl->result==0): ?><?php echo e($bl->bet_placed); ?><?php else: ?><?php echo e('0.00'); ?><?php endif; ?></td>
<td>0.00</td>
<td>0.00</td>
<td>0.00</td>
<td><?php if($bl->result==1): ?><?php echo e($bl->bet_placed*($bl->odd_req-1)); ?><?php else: ?><?php echo e('0.00'); ?><?php endif; ?></td>
<td><a href="<?php echo e(route('delete-bet').'?id='.$bl->bet_history_id); ?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<tr>
<td colspan="14" class="text-center no-data-table-bg">There is no data for selected filters.</td>
</tr>
<?php endif; ?><?php /**PATH /home/u254575789/domains/lordexworld.com/public_html/resources/views/agent/bet-list-yesterday-search.blade.php ENDPATH**/ ?>