<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="">
  <meta name="author" content="NobleUI">
  <meta name="keywords" content="">
  <?php echo $__env->make('layouts.header-url', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script>
    $(document).ready(function() {
      // Initially hide the filter section and remove active class
      $("#filterSection").hide();
      $("#toggleFilterSection").removeClass("active");

      // Toggle the filter section and toggle active class on button click
      $("#toggleFilterSection").click(function() {
        $("#filterSection").toggle();
        $("#toggleFilterSection").toggleClass("active");
      });
    });
  </script>
</head>

<body>
  <div class="main-wrapper Dashboard-bg admin-bg customResponsive">
    <!-- partial:partials/_sidebar.html -->
    <div class="left-side-bar"><?php echo $__env->make('layouts.left-side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
    <div class="page-wrapper bg-none">
      <!-- partial:partials/_navbar.html -->
      <div class="top-header-section"><?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
      <!-- partial -->
      <div class="page-content">
        <div class="Welcometo-section">
          <?php echo $__env->make('layouts.top-balance-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row">
          <div class="col-xl-12 grid-margin stretch-card">
            <div class="card overflow-hidden">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-baseline mb-4 mb-md-3 pb-2 border-bottom">
                  <div class="d-inline-flex align-items-center">
                    <h4 class=" mb-0">Bet List</h4>

                    <input type="hidden" value="current" name="bet_list" id="bet_list" >

                    <input class="form-control event-search" id="url"  value="<?php echo e(url('/')); ?>" type="hidden" placeholder="Event">

                    <form action="<?php echo e(route('bet-list')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                    <div class="d-inline-flex mx-2 filter-group statement-fltr" style="    margin-left: 28px !important;">
                      <div class="relative calender_icon-style">
                        <input type="datetime-local" name="from_date"  value="<?php if(isset($from_date)): ?><?php echo e($from_date); ?><?php endif; ?>" id="from_date" class="ng-valid-ng-dirty-ng-touched m-0">
                      </div>
                      <div class="relative calender_icon-style">
                        <input type="datetime-local" name="to_date" value="<?php if(isset($to_date)): ?><?php echo e($to_date); ?><?php endif; ?>" id="to_date" class="ng-valid-ng-dirty-ng-touched m-0">
                      </div>
                    </div>
                    <button type="submit" class="filter-applybtn" id="toggleFilterSection">
                      <img src="<?php echo e(asset('admin/Super-Admin/assets/icons/filter.png')); ?>">
                    </button>
                    </form>
                    <div class="mx-5">
                      <div class="form-check form-check-inline">
                        <input type="radio" class="form-check-input" name="sports_name" id="sports_for_sports" <?php if(isset($sports_name) && $sports_name=='sports'): ?><?php echo e('checked'); ?><?php endif; ?> value="sports" onclick="searchbdetlist()">
                        <label class="form-check-label" for="sports_for_sports">
                          Sports
                        </label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input type="radio" class="form-check-input" name="sports_name" id="sports_for_xg" <?php if(isset($sports_name) && $sports_name=='xg'): ?><?php echo e('checked'); ?><?php endif; ?>  value="xg"  onclick="searchbdetlist()">
                        <label class="form-check-label" for="sports_for_xg">
                          XG
                        </label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input type="radio" class="form-check-input" name="sports_name" id="sports_for_casino" <?php if(isset($sports_name) && $sports_name=='casino'): ?><?php echo e('checked'); ?><?php endif; ?>  value="casino"  onclick="searchbdetlist()">
                        <label class="form-check-label" for="sports_for_casino">
                          Live Casino
                        </label>
                      </div>

                    </div>
                  </div>
                  <div class="btn_Download d-inline-flex text-nowrap">
                    <button type="button" onclick="downloadbetlist('admin/bet-list-download')" class="btn btn-primary Refresh btn-icon-text mb-2 mb-md-0 mx-2">
                      Download CSV
                    </button>
                  </div>
                </div>
                <div class="Pand-l-Statement">
                  <div class="card-body_agent-listing-demoag5">
                 
                    <nav class="Account-Statement-nav mb-3">
                      <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true" onclick="changebetlisttype('current')">Current</button>
                        <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false" onclick="changebetlisttype('past')" tabindex="-1">Past</button>
                      </div>
                    </nav>
                    <div id="bet_list_id">
                <?php echo $__env->make('agent.all-bet-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    $('#config-demo').daterangepicker({
      "timePicker": true,
      "linkedCalendars": false,
      "startDate": "12/13/2023",
      "endDate": "12/19/2023",
      "opens": "center"
    }, function(start, end, label) {
      console.log("New date range selected: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');
    });
  </script>
  <style>
    hr {
      color: white;
      opacity: 0.5;
    }
  </style>

  <script>
    
  </script>

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u254575789/domains/lordexworld.com/public_html/resources/views/agent/bet-list.blade.php ENDPATH**/ ?>