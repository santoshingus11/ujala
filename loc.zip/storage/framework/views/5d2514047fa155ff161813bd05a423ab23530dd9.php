<div class="Agent_-Listings">
                      <div class="table-responsive border-bottom">
                        <table class="table-s table-exchange w-100 mt-5">
                          <thead>
                            <tr>
                              <th colspan="9" class="table-s-header">UnMatched</th>
                            </tr>
                          </thead>
                          <tbody class="">
                            <tr>
                              <th width="" class="text-start">Market
                              </th>
                              <th width="">Selection
                              </th>
                              <th width="">Type
                              </th>
                              <th width="">Bet ID
                              </th>
                              <th width="">Bet placed
                              </th>
                              <th width="">Odds req.
                              </th>
                              <th width="">Matched
                              </th>
                              <th width="">Unmatched
                              </th>
                              <th width="">Date matched
                              </th>
                            </tr>
                          </tbody>
                          <tbody id="Unmatched_Content">
                          <?php $__currentLoopData = $bet_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                           
                          <?php if($bl->type=='unmatched'): ?>
                          <tr id="noDataTemplate" style="display: table-row;">
                              <td><?php echo e($bl->market_name); ?></td>
                              <td><?php echo e($bl->selection_name); ?></td>
                              <td><?php echo e($bl->bet_type); ?></td>
                              <td><?php echo e($bl->bet_history_id); ?></td>
                              <td><?php echo e($bl->bet_placed); ?></td>
                              <td><?php echo e($bl->odd_req); ?></td>
                              <td>--</td>
                              <td>--</td>
                              <td><?php echo e($bl->match_date); ?></td>
                          </tr>                          
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                        <table class="table-s table-exchange w-100 mt-5">
                          <thead>
                            <tr>
                              <th colspan="9" class="table-s-header">Pending</th>
                            </tr>
                          </thead>
                          <tbody class="">
                            <tr>
                              <th width="" class="text-start">Market
                              </th>
                              <th width="">Selection
                              </th>
                              <th width="">Type
                              </th>
                              <th width="">Bet ID
                              </th>
                              <th width="">Bet placed
                              </th>
                              <th width="">Odds req.
                              </th>
                              <th width="">Matched
                              </th>
                              <th width="">Unmatched
                              </th>
                              <th width="">Date matched
                              </th>
                            </tr>
                          </tbody>
                          <tbody id="Unmatched_Content">
                          <?php $__currentLoopData = $bet_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                           
                          <?php if($bl->type=='pending'): ?>
                          <tr id="noDataTemplate" style="display: table-row;">
                              <td><?php echo e($bl->market_name); ?></td>
                              <td><?php echo e($bl->selection_name); ?></td>
                              <td><?php echo e($bl->bet_type); ?></td>
                              <td><?php echo e($bl->bet_history_id); ?></td>
                              <td><?php echo e($bl->bet_placed); ?></td>
                              <td><?php echo e($bl->odd_req); ?></td>
                              <td>--</td>
                              <td>--</td>
                              <td><?php echo e($bl->match_date); ?></td>
                          </tr>                         
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                        <table class="table-s table-exchange w-100 mt-5">
                          <thead>
                            <tr>
                              <th colspan="9" class="table-s-header">Matched</th>
                            </tr>
                          </thead>
                          <tbody class="">
                            <tr>
                              <th width="" class="text-start">Market
                              </th>
                              <th width="">Selection
                              </th>
                              <th width="">Type
                              </th>
                              <th width="">Bet ID
                              </th>
                              <th width="">Bet placed
                              </th>
                              <th width="">Odds req.
                              </th>
                              <th width="">Matched
                              </th>
                              <th width="">Unmatched
                              </th>
                              <th width="">Date matched
                              </th>
                            </tr>
                          </tbody>
                          <tbody id="Unmatched_Content">
                          <?php $__currentLoopData = $bet_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                           
                          <?php if($bl->type=='matched'): ?>
                          <tr id="noDataTemplate" style="display: table-row;">
                              <td><?php echo e($bl->market_name); ?></td>
                              <td><?php echo e($bl->selection_name); ?></td>
                              <td><?php echo e($bl->bet_type); ?></td>
                              <td><?php echo e($bl->bet_history_id); ?></td>
                              <td><?php echo e($bl->bet_placed); ?></td>
                              <td><?php echo e($bl->odd_req); ?></td>
                              <td>--</td>
                              <td>--</td>
                              <td><?php echo e($bl->match_date); ?></td>
                          </tr>                         
                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>

                    </div>
<?php /**PATH /home/u254575789/domains/lordexworld.com/public_html/resources/views/agent/bet-list-live-search.blade.php ENDPATH**/ ?>