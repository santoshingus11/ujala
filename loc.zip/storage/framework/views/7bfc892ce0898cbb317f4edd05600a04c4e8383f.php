<?php
$adminAccess = [];
if (isset(Auth::guard('agent')->user()->admin_access) && Auth::guard('agent')->user()->user_access == '1') {
    $userdata = Auth::guard('agent')->user();
    $adminAccessArray = explode(',', $userdata->admin_access);

    foreach ($adminAccessArray as $item) {
        // Only proceed if there is a key-value pair
        if (strpos($item, '=')) {
            list($key, $value) = explode('=', $item);
            $adminAccess[$key] = $value;
        }
    }
}

?>
<?php if(($adminAccess!='')): ?>
<ul class="nav">
  
  <?php if(isset($adminAccess['client_list'])): ?>
  <?php if($adminAccess['client_list'] === '1'): ?>
  <li class="nav-item">
    <a class="nav-link" data-bs-toggle="collapse" href="#ManagementPosition" role="button" aria-expanded="false" aria-controls="ManagementPosition">
      <span class="link-title">Agency Management</span>
      <i class="link-arrow" data-feather="chevron-down"></i>
    </a>
    <div class="collapse" id="ManagementPosition">
      <ul class="nav sub-menu">
     
      
        <a href="<?php echo e(route('agent-listing')); ?>" class="nav-link"> Master Listing</a>
        <?php if((Auth::guard('agent')->user()->role_id==4)): ?>
        <a href="<?php echo e(route('agent-listing')); ?>" class="nav-link"> Agent Listing</a> 
        <?php endif; ?>
      </li>
      
      
      
      </ul>
    </div>
  </li>
  <?php endif; ?>
  <?php endif; ?>
      <?php if(isset($adminAccess['agency_management'])): ?>
        <?php if($adminAccess['agency_management'] === '0'): ?>
          <?php elseif($adminAccess['agency_management'] ==='2'): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ManagementPosition" role="button" aria-expanded="false" aria-controls="ManagementPosition">
              <span class="link-title">Agency Management</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="ManagementPosition">
              <ul class="nav sub-menu">
             
                <?php if(Auth::guard('agent')->user()->role_id==1): ?>
                <a href="<?php echo e(route('super-master-listing')); ?>" class="nav-link"> Admin Listing</a>
                <?php elseif(Auth::guard('agent')->user()->role_id==2): ?>
                <a href="<?php echo e(route('super-master-listing')); ?>" class="nav-link"> Super Master Listing</a>
                 
                <?php endif; ?>
              </li>
              <?php if(Auth::guard('agent')->user()->role_id==1 || Auth::guard('agent')->user()->role_id==2): ?>
              <li class="nav-item">
                <a href="<?php echo e(route('position-taking-listing')); ?>" class="nav-link"> Position Taking Listing</a>
              </li>
              <?php endif; ?>
              <li class="nav-item">
                <a href="<?php echo e(route('agency-management-transfer')); ?>" class="nav-link"> Transfer</a>
              </li>
              
              </ul>
            </div>
          </li>
            <?php elseif($adminAccess['agency_management'] === '1'): ?>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="collapse" href="#ManagementPosition" role="button" aria-expanded="false" aria-controls="ManagementPosition">
                <span class="link-title">Agency Management</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
                </a>
                <div class="collapse" id="ManagementPosition">
                    <ul class="nav sub-menu">
                        <li class="nav-item">
                        <?php if(isset($adminAccess['admin_listing'])): ?>
                            <?php if($adminAccess['admin_listing'] === '0'): ?>
                                <?php if(Auth::guard('agent')->user()->role_id=='1'): ?>
                                  <a href="javascript:void(0)" class="nav-link"> Admin Listing</a>
                                <?php elseif(Auth::guard('agent')->user()->role_id=='2'): ?>
                                <a href="javascript:void(0)" class="nav-link"> Super Master Listing</a>
                                <?php endif; ?>
                            <?php elseif($adminAccess['admin_listing'] === '1' || $adminAccess['admin_listing'] === '2'): ?>

                            <a href="<?php echo e(route('super-master-listing')); ?>" class="nav-link"> 
                              <?php if(Auth::guard('agent')->user()->role_id=='1'): ?>
                              Admin Listing
                              <?php elseif(Auth::guard('agent')->user()->role_id=='2'): ?>
                              Super Master listing
                              <?php endif; ?>
                            </a>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        
                        
                        </li>
                      <?php if(isset($adminAccess['position_taking'])): ?>
                        <?php if($adminAccess['position_taking'] === '0'): ?>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link"> Position Taking Listing</a>
                        </li>
                        <?php elseif($adminAccess['position_taking'] === '1' || $adminAccess['position_taking'] ==='2'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('position-taking-listing')); ?>" class="nav-link"> Position Taking Listing</a>
                        </li>
                        <?php endif; ?>
                      <?php endif; ?>
                    <?php if(isset($adminAccess['transfer'])): ?>
                      <?php if($adminAccess['transfer'] === '0'): ?>
                      <li class="nav-item">
                          <a href="javascript:void(0)" class="nav-link"> Transfer</a>
                      </li>
                      <?php else: ?>
                      <li class="nav-item">
                          <a href="<?php echo e(route('agency-management-transfer')); ?>" class="nav-link">Transfer</a>
                      </li>
                      <?php endif; ?>
                    <?php endif; ?>
                    
                </div>
                </li>
        <?php endif; ?>
      <?php endif; ?>
        <?php if(isset($adminAccess['risk_management'])): ?>
          <?php if($adminAccess['risk_management'] === '0'): ?>
          <?php elseif( $adminAccess['risk_management'] === '2'): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#RiskManagement" role="button" aria-expanded="false" aria-controls="RiskManagement">
              <span class="link-title">Risk Management</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="RiskManagement">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="<?php echo e(route('net-exposure')); ?>" class="nav-link">Net Exposure</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('bet-ticker')); ?>" class="nav-link">Bet Ticker</a>
                </li>
              </ul>
            </div>
          </li>
          
            <?php elseif($adminAccess['risk_management'] =='1'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#RiskManagement" role="button" aria-expanded="false" aria-controls="RiskManagement">
                <span class="link-title">Risk Management</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="RiskManagement">
                <ul class="nav sub-menu">
                  <?php if(isset($adminAccess['net_exposure'])): ?>
                    <?php if($adminAccess['net_exposure']==='0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link">Net Exposure</a>
                    </li>
                    <?php elseif($adminAccess['net_exposure']==='1' || $adminAccess['net_exposure']==='2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('net-exposure')); ?>" class="nav-link">Net Exposure</a>
                      </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['bet_ticker'])): ?>
                    <?php if($adminAccess['bet_ticker']==='0'): ?>
                    <li class="nav-item">
                      <a href="<?php echo e(route('bet-ticker')); ?>" class="nav-link">Bet Ticker</a>
                    </li>
                    <?php elseif($adminAccess['bet_ticker']==='1' || $adminAccess['bet_ticker']==='2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('bet-ticker')); ?>" class="nav-link">Bet Ticker</a>
                      </li>
                    <?php endif; ?>
                  <?php endif; ?>
                </ul>
              </div>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(Auth::guard('agent')->user()->role_id=='3' || Auth::guard('agent')->user()->role_id=='4'): ?>
          <?php if( array_key_exists('my_bets', $adminAccess) ||
          array_key_exists('casino_report', $adminAccess) ||
          array_key_exists('bank_list', $adminAccess) ||
          array_key_exists('game_report', $adminAccess)
      ): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#Reports" role="button" aria-expanded="false" aria-controls="Reports">
              <span class="link-title">Reports</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="Reports">
              <ul class="nav sub-menu">
                <?php if(isset($adminAccess['my_bets'])): ?>
                  <?php if(($adminAccess['my_bets']=='1')): ?>
                  <li class="nav-item">
                  <a href="<?php echo e(route('my-bets-report')); ?>" class="nav-link"> My Bets Reports </a>
                  </li>
                  <?php endif; ?>
                <?php endif; ?>
                <?php if(isset($adminAccess['bank_list'])): ?>
                  <?php if(($adminAccess['bank_list']=='1')): ?>
                  <li class="nav-item">
                  <a href="<?php echo e(route('transfer-statement')); ?>" class="nav-link"> Transfer Statement </a>
                  </li>
                  <?php endif; ?>
                <?php endif; ?>
                <?php if(isset($adminAccess['casino_list'])): ?>
                  <?php if(($adminAccess['casino_list']=='1')): ?>
                  <li class="nav-item">
                  <a href="<?php echo e(route('casino-result')); ?>" class="nav-link"> Casino Result </a>
                  </li>
                  <?php endif; ?>
                <?php endif; ?>
                <?php if(isset($adminAccess['game_report'])): ?>
                  <?php if(($adminAccess['game_report']=='1')): ?>
                  <li class="nav-item">
                  <a href="<?php echo e(route('game-report')); ?>" class="nav-link"> Game Report </a>
                  </li>
                  <?php endif; ?>
                <?php endif; ?>

                
                
              </ul>
            </div>
          </li>
          <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['reports'])): ?>
            <?php if($adminAccess['reports'] === '0'): ?>
            <?php elseif($adminAccess['reports'] === '2'): ?>
              <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="collapse" href="#Reports" role="button" aria-expanded="false" aria-controls="Reports">
                  <span class="link-title">Reports</span>
                  <i class="link-arrow" data-feather="chevron-down"></i>
                  </a>
                  <div class="collapse" id="Reports">
                  <ul class="nav sub-menu">
          
                  <?php if(Auth::guard('agent')->user()->role_id==1 || Auth::guard('agent')->user()->role_id==2): ?>
                      <li class="nav-item">
                      <a href="<?php echo e(route('p-and-l-report-by-market')); ?>" class="nav-link"> P&L Report by Market</a>
                      </li>
                      <li class="nav-item">
                      <a href="<?php echo e(route('p-and-l-report-by-agent')); ?>" class="nav-link"> P&L Report by Agent</a>
                      </li>
                      <?php endif; ?>
                    
                      <?php if(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                      <li class="nav-item">
                      <a href="<?php echo e(route('profit-loss-report')); ?>" class="nav-link"> Profit Loss Report</a>
                      </li>
                      <li class="nav-item">
                      <a href="<?php echo e(route('transfer-statement')); ?>" class="nav-link"> Transfer Statement</a>
                      </li>
                      <?php endif; ?>
                      <li class="nav-item">
                      <?php if(Auth::guard('agent')->user()->role_id==1 || Auth::guard('agent')->user()->role_id==2): ?>
                      <a href="<?php echo e(route('casino-report')); ?>" class="nav-link"> Casino Report</a>
                      <?php elseif(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                      <a href="<?php echo e(route('casino-result')); ?>" class="nav-link"> Casino Result</a>
                      <?php endif; ?>
                      </li>
                      <?php if(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                      <li class="nav-item">
                      <a href="<?php echo e(route('game-report')); ?>" class="nav-link"> Game Report</a>
                      </li>
                      <li class="nav-item">
                      <a href="<?php echo e(route('message-report')); ?>" class="nav-link"> Message Report</a>
                      </li>
                      <?php endif; ?>
                      <?php if(Auth::guard('agent')->user()->role_id==2): ?>
                      <li class="nav-item">
                      <a href="<?php echo e(route('bet-list')); ?>" class="nav-link">Bet list</a>
                      </li>
                      <?php endif; ?>
                      <?php if(Auth::guard('agent')->user()->role_id==1): ?>
                      <li class="nav-item">
                      <a href="<?php echo e(route('user-transfer-statement')); ?>" class="nav-link"> Transfer Statement</a>
                      </li>
                      <?php endif; ?>
                  </ul>
                  </div>
              </li>
            <?php elseif($adminAccess['reports'] === '1'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Reports" role="button" aria-expanded="false" aria-controls="Reports">
                <span class="link-title">Reports</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Reports">
                <ul class="nav sub-menu">
                  <?php if(isset($adminAccess['p_l_report_market'])): ?>
                    <?php if($adminAccess['p_l_report_market']==='0'): ?>
                    <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link"> P&L Report by Market</a>
                      </li>
                    <?php elseif($adminAccess['p_l_report_market']==='1' || $adminAccess['p_l_report_market']==='2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('p-and-l-report-by-market')); ?>" class="nav-link"> P&L Report by Market</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['p_l_report_agent'])): ?>
                    <?php if($adminAccess['p_l_report_agent']==='0'): ?>
                    <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link">P&L Report by Agent</a>
                      </li>
                    <?php elseif($adminAccess['p_l_report_agent']==='1' || $adminAccess['p_l_report_agent']==='2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('p-and-l-report-by-agent')); ?>" class="nav-link"> P&L Report by Agent</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  
                  <?php if(isset($adminAccess['transfer_statement'])): ?>
                    <?php if($adminAccess['transfer_statement']==='0'): ?>
                    <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link"> Casino Report</a>
                    </li>
                    <?php elseif($adminAccess['casino_report']==='1' || $adminAccess['casino_report']==='2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('casino-report')); ?>" class="nav-link"> Casino Report</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['transfer_statement'])): ?>
                    <?php if($adminAccess['transfer_statement']==='0'): ?>
                    <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link"> Transfer Statement</a>
                    </li>
                    <?php elseif($adminAccess['transfer_statement']==='1' || $adminAccess['transfer_statement']==='2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('user-transfer-statement')); ?>" class="nav-link"> Transfer Statement</a>
                  </li>
                  <?php endif; ?>
                <?php endif; ?>
        
                
                </ul>
              </div>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['account_management'])): ?>
              <?php if($adminAccess['account_management'] === '0'): ?>
                <?php elseif($adminAccess['account_management'] === '2'): ?>
                    <li class="nav-item">
                        <a class="nav-link" data-bs-toggle="collapse" href="#AccountManagement" role="button" aria-expanded="false" aria-controls="AccountManagement">
                        <span class="link-title">Account Management</span>
                        <i class="link-arrow" data-feather="chevron-down"></i>
                        </a>
                        <div class="collapse" id="AccountManagement">
                        <ul class="nav sub-menu">
                            <li class="nav-item">
                            <?php if(Auth::guard('agent')->user()->role_id==1 || Auth::guard('agent')->user()->role_id==2): ?>
                            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Balance</a>
                            <?php elseif(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                            <a href="<?php echo e(route('account-statement')); ?>" class="nav-link">Account Statement</a>
                            <?php endif; ?>
                            </li>
                            <li class="nav-item">
                            <?php if(Auth::guard('agent')->user()->role_id==1 || Auth::guard('agent')->user()->role_id==2): ?>
                            <a href="<?php echo e(route('user-statement-account-statement')); ?>" class="nav-link">Statement</a>
                            <?php elseif(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                            <a href="<?php echo e(route('client-account-statement')); ?>" class="nav-link">Client Account Statement</a>
                            <?php endif; ?>
                            </li>
                            <?php if(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                            <li class="nav-item">
                            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Balance</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                        </div>
                    </li>
                    <?php elseif($adminAccess['account_management'] === '1'): ?>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="collapse" href="#AccountManagement" role="button" aria-expanded="false" aria-controls="AccountManagement">
                    <span class="link-title">Account Management</span>
                    <i class="link-arrow" data-feather="chevron-down"></i>
                    </a>
                    <div class="collapse" id="AccountManagement">
                    <ul class="nav sub-menu">
                      <?php if(isset($adminAccess['balance'])): ?>
                          <?php if($adminAccess['balance'] === '0'): ?>
                          <li class="nav-item">
                          <a href="javascript:void(0)" class="nav-link">Balance</a>
                          </li>
                          <?php elseif($adminAccess['balance'] === '1' || $adminAccess['balance'] === '2'): ?>
                          <li class="nav-item">
                              <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Balance</a>
                          </li>
                          <?php endif; ?>
                      <?php endif; ?>
                      <?php if(isset($adminAccess['account_statement'])): ?>
                        <?php if($adminAccess['account_statement'] === '0'): ?>
                        <li class="nav-item">
                        <a href="javascript:void(0)" class="nav-link">Statement</a>
                        </li>
                        <?php elseif($adminAccess['account_statement'] === '1' || $adminAccess['account_statement'] === '2'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('client-account-statement')); ?>" class="nav-link">Statement</a>
                        </li>
                        <?php endif; ?>
                      <?php endif; ?>
                    </ul>
                    </div>
                </li>
                <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['user_create'])): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#UserListing" role="button" aria-expanded="false" aria-controls="UserListing">
              <span class="link-title">Admin Users</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="UserListing">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="<?php echo e(route('create-account')); ?>" class="nav-link">Create Account</a>
                </li>
              </ul>
            </div>
          </li>
          <?php endif; ?>
          <?php if(isset($adminAccess['admin_user'])): ?>
                <?php if($adminAccess['admin_user'] === '0'): ?>
                <?php elseif($adminAccess['admin_user'] === '2'): ?>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="collapse" href="#UserListing" role="button" aria-expanded="false" aria-controls="UserListing">
                      <span class="link-title">Admin Users</span>
                      <i class="link-arrow" data-feather="chevron-down"></i>
                    </a>
                    <div class="collapse" id="UserListing">
                      <ul class="nav sub-menu">
                        <li class="nav-item">
                        <?php if(Auth::guard('agent')->user()->role_id==1 || Auth::guard('agent')->user()->role_id==2): ?>
                          <a href="<?php echo e(route('user-listing')); ?>" class="nav-link"> User Listing</a>
                          <?php elseif(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                          <a href="<?php echo e(route('create-account')); ?>" class="nav-link">Create Account</a>
                          <?php endif; ?>
                        </li>
                      </ul>
                    </div>
                    <?php if(Auth::guard('agent')->user()->role_id==3 || Auth::guard('agent')->user()->role_id==4): ?>
                    <li class="nav-item">
                    <a class="nav-link blinking-new" data-bs-toggle="collapse" href="#LiveCasino" role="button" aria-expanded="false" aria-controls="LiveCasino">
                      <span class="link-title">Live Casino</span>
                      <i class="link-arrow" data-feather="chevron-down"></i>
                    </a>
                    <div class="collapse" id="LiveCasino">
                      <ul class="nav sub-menu">
                        <li class="nav-item">
                          <a href="<?php echo e(route('live-casino')); ?>" class="nav-link">Live Casino</a>
                        </li>
                      </ul>
                    </div>
                  </li>
                  <?php endif; ?>
                  </li>
                <?php elseif($adminAccess['admin_user'] === '1'): ?>
                <li class="nav-item">
                    <a class="nav-link" data-bs-toggle="collapse" href="#UserListing" role="button" aria-expanded="false" aria-controls="UserListing">
                      <span class="link-title">Admin Users</span>
                      <i class="link-arrow" data-feather="chevron-down"></i>
                    </a>
                    <div class="collapse" id="UserListing">
                      <ul class="nav sub-menu">
                        <?php if(isset($adminAccess['user_listing'])): ?>
                          <?php if($adminAccess['user_listing'] === '0'): ?>
                          <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link"> User Listing</a>
                          </li>
                          <?php elseif($adminAccess['user_listing'] === '1' || $adminAccess['user_listing'] === '2'): ?>
                          <li class="nav-item">
                              <a href="<?php echo e(route('user-listing')); ?>" class="nav-link"> User Listing</a>
                            </li>
                            <?php endif; ?>
                        <?php endif; ?>
                      </ul>
                    </div>
                  </li>
              <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['bet'])): ?>
            <?php if($adminAccess['bet'] === '0'): ?>
            <?php elseif($adminAccess['bet'] === '2'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Bet" role="button" aria-expanded="false" aria-controls="Bet">
                <span class="link-title">Bet</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Bet">
                <ul class="nav sub-menu">
                  <li class="nav-item">
                    <a href="<?php echo e(route('bet-list')); ?>" class="nav-link">Bet List</a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo e(route('bet-list-live')); ?>" class="nav-link">Bet List Live</a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo e(route('bet-limit')); ?>" class="nav-link">Bet Limit</a>
                  </li>
                </ul>
              </div>
            </li>
            <?php elseif($adminAccess['bet'] === '1'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Bet" role="button" aria-expanded="false" aria-controls="Bet">
                <span class="link-title">Bet</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Bet">
                <ul class="nav sub-menu">
                  <?php if(isset($adminAccess['bet_list'])): ?>
                    <?php if($adminAccess['bet_list'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Bet List</a>
                    </li>
                    <?php elseif($adminAccess['bet_list'] === '1' || $adminAccess['bet_list'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('bet-list')); ?>" class="nav-link">Bet List</a>
                    </li>
                      <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['bet_list_live'])): ?>
                    <?php if($adminAccess['bet_list_live'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Bet List Live</a>
                    </li>
                    <?php elseif($adminAccess['bet_list_live'] === '1' || $adminAccess['bet_list_live'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('bet-list-live')); ?>" class="nav-link">Bet List Live</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['bet_limit'])): ?>
                    <?php if($adminAccess['bet_limit'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Bet Limit</a>
                    </li>
                    <?php elseif($adminAccess['bet_limit'] === '1' || $adminAccess['bet_limit'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('bet-limit')); ?>" class="nav-link">Bet Limit</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                </ul>
              </div>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['extra'])): ?>
            <?php if($adminAccess['extra'] === '0'): ?>
            <?php elseif($adminAccess['extra'] === '2'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Extra" role="button" aria-expanded="false" aria-controls="Extra">
                <span class="link-title">Extra</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Extra">
                <ul class="nav sub-menu">
                  <!-- <li class="nav-item">
                    <a href="<?php echo e(route('banner-update')); ?>" class="nav-link">Banner Update</a>
                  </li> -->
                  <li class="nav-item">
                    <a href="<?php echo e(route('news-update')); ?>" class="nav-link">News Update</a>
                  </li>
                  <li class="nav-item">
                    <a href="<?php echo e(route('client-notification')); ?>" class="nav-link">Client Notification</a>
                  </li>
                </ul>
              </div>
            </li>
            <?php elseif($adminAccess['extra'] === '1'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Extra" role="button" aria-expanded="false" aria-controls="Extra">
                <span class="link-title">Extra</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Extra">
                <ul class="nav sub-menu">
                  <?php if(isset($adminAccess['banner_update'])): ?>
                    <?php if($adminAccess['banner_update'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Banner Update</a>
                    </li>
                    <?php elseif($adminAccess['banner_update'] === '1' || $adminAccess['banner_update'] === '2'): ?>
                    <!-- <li class="nav-item">
                        <a href="<?php echo e(route('banner-update')); ?>" class="nav-link">Banner Update</a>
                    </li> -->
                      <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['news_update'])): ?>
                    <?php if($adminAccess['news_update'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link">News Update</a>
                    </li>
                    <?php elseif($adminAccess['news_update'] === '1' || $adminAccess['news_update'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('news-update')); ?>" class="nav-link">News Update</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['client_notification'])): ?>
                    <?php if($adminAccess['client_notification'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Client Notification</a>
                    </li>
                    <?php elseif($adminAccess['client_notification'] === '1' || $adminAccess['client_notification'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('client-notification')); ?>" class="nav-link">Client Notification</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                </ul>
              </div>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['player_log_report'])): ?>
              <?php if($adminAccess['player_log_report'] === '0'): ?>
              <?php elseif($adminAccess['player_log_report'] === '2'): ?>
                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="collapse" href="#PlayerLog" role="button" aria-expanded="false" aria-controls="PlayerLog">
                    <span class="link-title">Player Log & Report</span>
                    <i class="link-arrow" data-feather="chevron-down"></i>
                  </a>
                  <div class="collapse" id="PlayerLog">
                    <ul class="nav sub-menu">
                      <li class="nav-item">
                        <a href="<?php echo e(route('balance-log')); ?>" class="nav-link">Balance Log</a>
                      </li>
                      <li class="nav-item">
                        <a href="<?php echo e(route('player-betting-history')); ?>" class="nav-link">Player Betting History</a>
                      </li>
                      <li class="nav-item">
                        <a href="<?php echo e(route('player-profit-and-loss')); ?>" class="nav-link">Player Profit and Loss</a>
                      </li>
                      <!-- <li class="nav-item">
                        <a href="<?php echo e(route('chips-analysis')); ?>" class="nav-link">Chips Analysis</a>
                      </li> -->
                    </ul>
                  </div>
                </li>
              <?php elseif($adminAccess['player_log_report'] === '1'): ?>

                <li class="nav-item">
                  <a class="nav-link" data-bs-toggle="collapse" href="#PlayerLog" role="button" aria-expanded="false" aria-controls="PlayerLog">
                    <span class="link-title">Player Log & Report</span>
                    <i class="link-arrow" data-feather="chevron-down"></i>
                  </a>
                  <div class="collapse" id="PlayerLog">
                    <ul class="nav sub-menu">
                      <?php if(isset($adminAccess['balance_log'])): ?>
                        <?php if($adminAccess['balance_log'] === '0'): ?>
                        <li class="nav-item">
                          <a href="javascript:void(0)" class="nav-link"> Balance Log</a>
                        </li>
                        <?php elseif($adminAccess['balance_log'] === '1' || $adminAccess['balance_log'] === '2'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('balance-log')); ?>" class="nav-link">Balance Log</a>
                        </li>
                          <?php endif; ?>
                      <?php endif; ?>
                      <?php if(isset($adminAccess['betting_history'])): ?>
                        <?php if($adminAccess['betting_history'] === '0'): ?>
                        <li class="nav-item">
                          <a href="javascript:void(0)" class="nav-link">Player Betting History</a>
                        </li>
                        <?php elseif($adminAccess['betting_history'] === '1' || $adminAccess['betting_history'] === '2'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('player-betting-history')); ?>" class="nav-link">Player Betting History</a>
                        </li>
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php if(isset($adminAccess['player_profit_loss'])): ?>
                        <?php if($adminAccess['player_profit_loss'] === '0'): ?>
                        <li class="nav-item">
                          <a href="javascript:void(0)" class="nav-link"> Player Profit and Loss</a>
                        </li>
                        <?php elseif($adminAccess['player_profit_loss'] === '1' || $adminAccess['player_profit_loss'] === '2'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('player-profit-and-loss')); ?>" class="nav-link">Player Profit and Loss</a>
                        </li>
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php if(isset($adminAccess['chips_analysis'])): ?>
                        <?php if($adminAccess['chips_analysis'] === '0'): ?>
                        <li class="nav-item">
                          <a href="javascript:void(0)" class="nav-link"> Chips Analysis</a>
                        </li>
                        <?php elseif($adminAccess['chips_analysis'] === '1' || $adminAccess['chips_analysis'] === '2'): ?>
                        <!-- <li class="nav-item">
                            <a href="<?php echo e(route('chips-analysis')); ?>" class="nav-link">Chips Analysis</a>
                        </li> -->
                        <?php endif; ?>
                      <?php endif; ?>
                    </ul>
                  </div>
                </li>
              <?php endif; ?>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['main_market_setting'])): ?>
            <?php if($adminAccess['main_market_setting'] === '0'): ?>
            <?php elseif($adminAccess['main_market_setting'] === '2'): ?>
              <li class="nav-item">
                <a class="nav-link" data-bs-toggle="collapse" href="#MarketSetting" role="button" aria-expanded="false" aria-controls="MarketSetting">
                  <span class="link-title">Market Setting</span>
                  <i class="link-arrow" data-feather="chevron-down"></i>
                </a>
                <div class="collapse" id="MarketSetting">
                  <ul class="nav sub-menu">
                    <li class="nav-item">
                      <a href="<?php echo e(route('market-settings')); ?>" class="nav-link">Market Settings</a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('declare-market')); ?>" class="nav-link">Declare Market</a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('matchlock')); ?>" class="nav-link">Match Lock </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('market-rollback')); ?>" class="nav-link">Market Rollback </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('online-user')); ?>" class="nav-link">Online User </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('delete-bet-history')); ?>" class="nav-link">Delete Bet History </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('global-settings')); ?>" class="nav-link">Global Settings </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('fancy-setting')); ?>" class="nav-link">Fancy Setting </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('match-setting')); ?>" class="nav-link">Match Setting</a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('match-limit')); ?>" class="nav-link">Match Limit </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('suspend-all-market')); ?>" class="nav-link">Suspend All Market </a>
                    </li>
                    <li class="nav-item">
                      <a href="<?php echo e(route('score-card-and-tv')); ?>" class="nav-link">Score Card and TV </a>
                    </li>
          
                  </ul>
                </div>
              </li>
            <?php elseif($adminAccess['main_market_setting'] === '1'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#MarketSetting" role="button" aria-expanded="false" aria-controls="MarketSetting">
                <span class="link-title">Market Setting</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="MarketSetting">
                <ul class="nav sub-menu">
                  <?php if(isset($adminAccess['market_settings'])): ?>
                  <?php if($adminAccess['market_settings'] === '0'): ?>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link"> Market Settings</a>
                  </li>
                  <?php elseif($adminAccess['market_settings'] === '1' || $adminAccess['market_settings'] === '2'): ?>
                  <li class="nav-item">
                      <a href="<?php echo e(route('market-settings')); ?>" class="nav-link">Market Settings</a>
                  </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['declare_market'])): ?>
                    <?php if($adminAccess['declare_market'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link">Declare Market</a>
                    </li>
                    <?php elseif($adminAccess['declare_market'] === '1' || $adminAccess['declare_market'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('declare-market')); ?>" class="nav-link">Declare Market</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['match_lock'])): ?>
                    <?php if($adminAccess['match_lock'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Match Lock</a>
                    </li>
                    <?php elseif($adminAccess['match_lock'] === '1' || $adminAccess['match_lock'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('matchlock')); ?>" class="nav-link">Match Lock</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['market_rollback'])): ?>
                    <?php if($adminAccess['market_rollback'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Market Rollback</a>
                    </li>
                    <?php elseif($adminAccess['market_rollback'] === '1' || $adminAccess['market_rollback'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('market-rollback')); ?>" class="nav-link">Market Rollback</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['online_user'])): ?>
                    <?php if($adminAccess['online_user'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Online User</a>
                    </li>
                    <?php elseif($adminAccess['online_user'] === '1' || $adminAccess['online_user'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('online-user')); ?>" class="nav-link">Online User</a>
                    </li>
                      <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['delete_bet_history'])): ?>
                    <?php if($adminAccess['delete_bet_history'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link">Delete Bet History</a>
                    </li>
                    <?php elseif($adminAccess['delete_bet_history'] === '1' || $adminAccess['delete_bet_history'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('delete-bet-history')); ?>" class="nav-link">Delete Bet History</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['global_settings'])): ?>
                    <?php if($adminAccess['global_settings'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Global Settings </a>
                    </li>
                    <?php elseif($adminAccess['global_settings'] === '1' || $adminAccess['global_settings'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('global-settings')); ?>" class="nav-link">Global Settings </a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['fancy_setting'])): ?>
                    <?php if($adminAccess['fancy_setting'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Fancy Setting </a>
                    </li>
                    <?php elseif($adminAccess['fancy_setting'] === '1' || $adminAccess['fancy_setting'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('fancy-setting')); ?>" class="nav-link">Fancy Setting </a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['match_setting'])): ?>
                    <?php if($adminAccess['match_setting'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Match Setting</a>
                    </li>
                    <?php elseif($adminAccess['match_setting'] === '1' || $adminAccess['match_setting'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('match-setting')); ?>" class="nav-link">Match Setting</a>
                    </li>
                      <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['match_limit'])): ?>
                    <?php if($adminAccess['match_limit'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link">Match Limit </a>
                    </li>
                    <?php elseif($adminAccess['match_limit'] === '1' || $adminAccess['match_limit'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('match-limit')); ?>" class="nav-link">Match Limit </a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['suspend_all_market'])): ?>
                    <?php if($adminAccess['suspend_all_market'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Suspend All Market</a>
                    </li>
                    <?php elseif($adminAccess['suspend_all_market'] === '1' || $adminAccess['suspend_all_market'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('suspend-all-market')); ?>" class="nav-link">Suspend All Market</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                  <?php if(isset($adminAccess['scorecard_tv'])): ?>
                    <?php if($adminAccess['scorecard_tv'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Score Card and TV</a>
                    </li>
                    <?php elseif($adminAccess['scorecard_tv'] === '1' || $adminAccess['scorecard_tv'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('score-card-and-tv')); ?>" class="nav-link">Score Card and TV</a>
                    </li>
                    <?php endif; ?>
                  <?php endif; ?>
                </ul>
              </div>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['my_report'])): ?>
          <?php if($adminAccess['my_report'] === '0'): ?>
          <?php elseif($adminAccess['my_report'] === '2'): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#MyReport" role="button" aria-expanded="false" aria-controls="MyReport">
              <span class="link-title">My Report</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="MyReport">
              <ul class="nav sub-menu">
                <li class="nav-item">
                  <a href="<?php echo e(route('profitLoss-report-by-downline')); ?>" class="nav-link">Profit/Loss Report by Downline</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('profitLoss-report-by-market')); ?>" class="nav-link">Profit/Loss Report by Market</a>
                </li>
              </ul>
            </div>
          </li>
          <?php elseif($adminAccess['my_report'] === '1'): ?>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#MyReport" role="button" aria-expanded="false" aria-controls="MyReport">
              <span class="link-title">My Report</span>
              <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="MyReport">
              <ul class="nav sub-menu">
                <?php if(isset($adminAccess['profit_loss_report_downline'])): ?>
                  <?php if($adminAccess['profit_loss_report_downline'] === '0'): ?>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link"> Profit/Loss Report by Downline </a>
                  </li>
                  <?php elseif($adminAccess['profit_loss_report_downline'] === '1' || $adminAccess['profit_loss_report_downline'] === '2'): ?>
                  <li class="nav-item">
                      <a href="<?php echo e(route('profitLoss-report-by-downline')); ?>" class="nav-link">Profit/Loss Report by Downline </a>
                  </li>
                  <?php endif; ?>
                <?php endif; ?>
                <?php if(isset($adminAccess['profit_loss_report_market'])): ?>
                  <?php if($adminAccess['profit_loss_report_market'] === '0'): ?>
                  <li class="nav-item">
                    <a href="javascript:void(0)" class="nav-link"> Profit/Loss Report by Market</a>
                  </li>
                  <?php elseif($adminAccess['profit_loss_report_market'] === '1' || $adminAccess['profit_loss_report_market'] === '2'): ?>
                  <li class="nav-item">
                      <a href="<?php echo e(route('profitLoss-report-by-market')); ?>" class="nav-link">Profit/Loss Report by Market</a>
                  </li>
                    <?php endif; ?>
                <?php endif; ?>
              </ul>
            </div>
          </li>
          <?php endif; ?>
         
          <?php if(isset($adminAccess['admin_risk'])): ?>
            <?php if($adminAccess['admin_risk'] === '0'): ?>
            <?php elseif($adminAccess['admin_risk'] === '2'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Risk" role="button" aria-expanded="false" aria-controls="Risk">
                <span class="link-title">Risk</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Risk">
                <ul class="nav sub-menu">
                  <li class="nav-item">
                    <a href="<?php echo e(route('risk-management')); ?>" class="nav-link">Risk Management</a>
                  </li>
                </ul>
              </div>
            </li>
            <?php elseif($adminAccess['admin_risk'] === '1'): ?>
            <li class="nav-item">
              <a class="nav-link" data-bs-toggle="collapse" href="#Risk" role="button" aria-expanded="false" aria-controls="Risk">
                <span class="link-title">Risk</span>
                <i class="link-arrow" data-feather="chevron-down"></i>
              </a>
              <div class="collapse" id="Risk">
                <ul class="nav sub-menu">
                  <?php if(isset($adminAccess['admin_risk_management'])): ?>
                    <?php if($adminAccess['admin_risk_management'] === '0'): ?>
                    <li class="nav-item">
                      <a href="javascript:void(0)" class="nav-link"> Risk Management</a>
                    </li>
                    <?php elseif($adminAccess['admin_risk_management'] === '1' || $adminAccess['admin_risk_management'] === '2'): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('risk-management')); ?>" class="nav-link">Risk Management</a>
                    </li>
                      <?php endif; ?>
                  <?php endif; ?>
                </ul>
              </div>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          
          <?php if(isset($adminAccess['password_history'])): ?>
            <?php if($adminAccess['password_history'] === '0'): ?>
            <?php elseif($adminAccess['password_history'] === '2' || $adminAccess['password_history'] === '1'): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('password-history')); ?>" class="nav-link">
                <span class="link-title">Password History</span>
              </a>
            </li>
          <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['commission'])): ?>
            <?php if($adminAccess['commission'] === '0'): ?>
            <?php elseif($adminAccess['commission'] === '2' || $adminAccess['commission'] === '1'): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('commission')); ?>" class="nav-link">
                <span class="link-title">Commission</span>
              </a>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['market_analysis'])): ?>
            <?php if($adminAccess['market_analysis'] === '0'): ?>
            <?php elseif($adminAccess['market_analysis'] === '2' || $adminAccess['market_analysis'] === '1'): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('market-analysis')); ?>" class="nav-link">
                <span class="link-title">Market Analysis</span>
              </a>
            </li>
         <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['void_market'])): ?>
            <?php if($adminAccess['void_market'] === '0'): ?>
            <?php elseif($adminAccess['void_market'] === '2' || $adminAccess['void_market'] === '1'): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('void-markets')); ?>" class="nav-link">
                <span class="link-title">Void markets</span>
              </a>
            </li>
            <?php endif; ?>
          <?php endif; ?>
          <?php if(isset($adminAccess['white_label'])): ?>
            <?php if($adminAccess['white_label'] === '0'): ?>
            <?php elseif($adminAccess['white_label'] === '2' || $adminAccess['white_label'] === '1'): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('white-lable')); ?>" class="nav-link">
                <span class="link-title">White Lable</span>
              </a>
            </li>
             <?php endif; ?>
          <?php endif; ?>

</ul>

<?php endif; ?><?php /**PATH /home/u254575789/domains/lordexworld.com/public_html/resources/views/agent/user_access_sidebar.blade.php ENDPATH**/ ?>